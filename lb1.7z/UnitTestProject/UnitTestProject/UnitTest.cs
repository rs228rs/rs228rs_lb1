﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Data;
using CalcClassBr;
using ErrorLibrary;

namespace UnitTestProject
{
    [TestClass]
    public class UnitTest
    {
        public TestContext TestContext { get; set; }
        [DataSource("Microsoft.VisualStudio.TestTools.DataSource.XML", "UnitTestData.xml", "TestData", DataAccessMethod.Sequential)]
        [TestMethod]
        public void TestMod()
        {
            string expexted = Convert.ToString(TestContext.DataRow["expected"]);
            long a = Convert.ToInt64(TestContext.DataRow["a"]);
            long b = Convert.ToInt64(TestContext.DataRow["b"]);
            long actual;
            try
            {
                actual = CalcClass.Mod(a, b);
                Assert.AreEqual(Convert.ToInt32(expexted), actual);
            }
            catch(DivideByZeroException)
            {
                Assert.AreEqual(expexted, ErrorsExpression.ERROR_09);
            }
            catch (ArgumentOutOfRangeException)
            {
                Assert.AreEqual(expexted, ErrorsExpression.ERROR_06);
            }
        }
    }
}
