﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CalcClassBr;
using System.Diagnostics;
namespace CalcClassBrModTest
{
    [TestClass]
    public class CalcClasTest
    {
        public TestContext TestContext { get; set; }
        [DataSource("Microsoft.VisualStudio.Testtools.DataSource.XML", "test_data.xml", "TestData", DataAccessMethod.Sequentail)]
        [TestMethod]
        public static void ModTest()
        {
            string expected = Convert.ToString(TestContext.DataRow["expected"]);
            string inactual = Convert.ToString(TestContext.DataRow["actual"]);
            string actual = CalcClass.Mod(inactual);
            Assert.AreEqual(expected, actual)
        }
    }
}
